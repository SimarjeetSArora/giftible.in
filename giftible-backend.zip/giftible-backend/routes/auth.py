import os
import jwt
import shutil
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Form, File, UploadFile
from sqlalchemy.orm import Session
from dotenv import load_dotenv
from passlib.context import CryptContext
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from database import get_db
from models import UniversalUser, RefreshToken, NGO
from schemas import (
    UserCreate, AdminCreate, UserResponse, 
    LogoutRequest, RefreshTokenRequest
)
from .utils import (
    create_access_token, create_refresh_token,
    save_refresh_token
)
from jose import jwt, JWTError

# 🚀 Load environment variables
router = APIRouter()
load_dotenv()

SECRET_KEY = os.getenv("SECRET_KEY", "your_secret_key")
REFRESH_SECRET_KEY = os.getenv("REFRESH_SECRET_KEY", "your_refresh_secret_key")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

UPLOAD_DIR = "uploads/"
os.makedirs(UPLOAD_DIR, exist_ok=True)


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    """Extracts and returns the current logged-in user based on JWT token."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")

        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")

        user = db.query(UniversalUser).filter(UniversalUser.id == user_id).first()
        if not user:
            raise HTTPException(status_code=401, detail="User not found")

        return user

    except jwt.ExpiredSignatureError:
        print("🔒 Token expired - forcing logout.")
        raise HTTPException(status_code=403, detail="Token expired. Please log in again.")  # 403 instead of 401

    except JWTError as e:
        print(f"❌ JWT Decode Error: {e}")  
        raise HTTPException(status_code=401, detail="Invalid token. Please log in again.")





# ✅ Universal User Registration
def register_universal_user(db: Session, data, role: str):
    try:
        existing_user = db.query(UniversalUser).filter(
            (UniversalUser.contact_number == data.contact_number) | 
            (UniversalUser.email == data.email)
        ).first()

        if existing_user:
            raise HTTPException(status_code=400, detail="Email or contact number already registered.")

        hashed_password = pwd_context.hash(data.password)
        new_user = UniversalUser(
            first_name=data.first_name,
            last_name=data.last_name,
            contact_number=data.contact_number,
            email=data.email,
            password=hashed_password,
            role=role
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return new_user

    except Exception as e:
        db.rollback()
        print(f"❌ Error registering user: {e}")  # Debug log
        raise HTTPException(status_code=500, detail="Internal server error.")



# ✅ User Registration
@router.post("/register/user", response_model=UserResponse)
def register_user(data: UserCreate, db: Session = Depends(get_db)):
    user = register_universal_user(db, data, "user")
    return user


# ✅ Admin Registration
@router.post("/register/admin", response_model=UserResponse)
def register_admin(data: AdminCreate, db: Session = Depends(get_db)):
    admin = register_universal_user(db, data, "admin")
    return admin


# ✅ NGO Registration
@router.post("/register/ngo")
def register_ngo(
    ngo_name: str = Form(...),
    first_name: str = Form(...),
    last_name: str = Form(...),
    email: str = Form(...),
    contact_number: str = Form(...),
    password: str = Form(...),
    account_holder_name: str = Form(...),
    account_number: str = Form(...),
    ifsc_code: str = Form(...),
    address: str = Form(...),
    city: str = Form(...),
    state: str = Form(...),
    pincode: str = Form(...),
    license: UploadFile = File(...),
    logo: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Registers an NGO by storing user authentication details in `UniversalUser`
    and other NGO-related details in `NGO`."""

    # ✅ Fix: Convert form data into a Pydantic model
    universal_user_data = UserCreate(
        first_name=first_name,
        last_name=last_name,
        email=email,
        contact_number=contact_number,
        password=password
    )

    # ✅ Now call register_universal_user() with the Pydantic model
    universal_user = register_universal_user(db, universal_user_data, "ngo")

    # ✅ Save license & logo files
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    license_filename = f"{timestamp}_{license.filename}"
    logo_filename = f"{timestamp}_{logo.filename}"

    license_path = os.path.join(UPLOAD_DIR, license_filename)
    logo_path = os.path.join(UPLOAD_DIR, logo_filename)

    # ✅ Save files safely
    with open(license_path, "wb") as buffer:
        shutil.copyfileobj(license.file, buffer)

    with open(logo_path, "wb") as buffer:
        shutil.copyfileobj(logo.file, buffer)
    # ✅ Insert NGO-specific details into the `NGO` table
    ngo_profile = NGO(
        universal_user_id=universal_user.id,  # ✅ Linking to UniversalUser
        ngo_name=ngo_name,
        account_holder_name=account_holder_name,
        account_number=account_number,
        ifsc_code=ifsc_code,
        address=address,
        city=city,
        state=state,
        pincode=pincode,
        license=license_path,
        logo=logo_path,
        is_approved=False
    )

    db.add(ngo_profile)
    db.commit()
    db.refresh(ngo_profile)

    return {"message": "✅ NGO registered successfully! Awaiting admin approval."}



# 🔑 Login (Universal for All Roles)
@router.post("/token")
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Unified login for all users via UniversalUser table using contact number."""
    try:
        print(f"🔍 Attempting login for contact number: {form_data.username}")

        # ✅ Query user by contact number instead of user ID
        user = db.query(UniversalUser).filter(UniversalUser.contact_number == form_data.username).first()

        if not user:
            print("❌ User not found")
            raise HTTPException(status_code=404, detail="User does not exist.")

        if not pwd_context.verify(form_data.password, user.password):
            print("❌ Incorrect password")
            raise HTTPException(status_code=401, detail="Incorrect password.")

        print("✅ Login successful!")

        # ✅ Generate tokens
        access_token = create_access_token(data={"sub": str(user.id), "role": user.role})
        refresh_token, refresh_expiry = create_refresh_token(data={"sub": str(user.id), "role": user.role})

        save_refresh_token(db, user.id, refresh_token, refresh_expiry)

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "role": user.role,
            "id": user.id,
            "first_name": user.first_name,
            "last_name": user.last_name
        }

    except Exception as e:
        print(f"❌ Login error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error.")







# 🚪 Logout & Revoke Token
@router.post("/logout")
def logout(request: LogoutRequest, db: Session = Depends(get_db)):
    """Removes the user's refresh token to log them out."""
    try:
        refresh_token = request.refresh_token  # ✅ Extract refresh_token
        print(f"🔒 Logging out refresh token: {refresh_token}")

        # ✅ Correct query to delete refresh token
        deleted = db.query(RefreshToken).filter(RefreshToken.token == refresh_token).delete()

        if deleted == 0:
            raise HTTPException(status_code=404, detail="Refresh token not found.")

        db.commit()
        return {"message": "✅ Successfully logged out"}

    except Exception as e:
        print(f"❌ Logout error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error.")


@router.post("/refresh-token")
def refresh_access_token(request: RefreshTokenRequest, db: Session = Depends(get_db)):
    refresh_token = request.refresh_token

    try:
        print(f"🔄 Refresh Token Received: {refresh_token}")  # Debug log
        
        payload = jwt.decode(refresh_token, REFRESH_SECRET_KEY, algorithms=[ALGORITHM])
        user_id = str(payload.get("sub"))

        print(f"🔎 Decoded Payload: {payload}")  # Debug log

        # ✅ Correct the query (use `universal_user_id`)
        token_entry = db.query(RefreshToken).filter_by(token=refresh_token, universal_user_id=user_id).first()
        if not token_entry:
            print("❌ Refresh token not found in DB")  # Debug log
            raise HTTPException(status_code=401, detail="Invalid refresh token.")

        if token_entry.expires_at < datetime.utcnow():
            print("❌ Refresh token expired!")  # Debug log
            raise HTTPException(status_code=401, detail="Refresh token expired.")

        # ✅ Generate new access token
        new_access_token = create_access_token({"sub": user_id, "role": payload.get("role")})

        print(f"✅ New Access Token Generated: {new_access_token}")  # Debug log
        return {"access_token": new_access_token}

    except jwt.ExpiredSignatureError:
        print("❌ Refresh token expired!")  # Debug log
        raise HTTPException(status_code=401, detail="Refresh token expired.")

    except JWTError as e:
        print(f"❌ JWT Error: {e}")  # Debug log
        raise HTTPException(status_code=401, detail="Invalid token.")
