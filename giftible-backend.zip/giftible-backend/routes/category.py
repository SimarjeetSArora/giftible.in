from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import Category, UniversalUser
from schemas import CategoryCreate, CategoryResponse, CategoryApproval
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
import os
from dotenv import load_dotenv

# 🚀 Load environment variables
router = APIRouter(prefix="/categories", tags=["Categories"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

load_dotenv()
SECRET_KEY = os.getenv("SECRET_KEY", "your_secret_key")
ALGORITHM = "HS256"

# 🔑 Get current user from token
def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> UniversalUser:
    try:
        if not token:
            raise HTTPException(status_code=401, detail="Token not provided.")

        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        contact_number = payload.get("sub")
        role = payload.get("role")

        if not contact_number or not role:
            raise HTTPException(status_code=401, detail="Invalid token payload.")

        user = db.query(UniversalUser).filter(UniversalUser.contact_number == contact_number).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found.")

        return user

    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token.")

# 🚀 NGO: Create a new category (default: Not approved)
@router.post("/", response_model=CategoryResponse, summary="NGO: Create a new category (Needs approval)")
def create_category(
    category: CategoryCreate,
    db: Session = Depends(get_db),
    current_user: UniversalUser = Depends(get_current_user)
):
    if current_user.role != "ngo":
        raise HTTPException(status_code=403, detail="Only NGOs can create categories.")

    # ✅ Check if category already exists
    if db.query(Category).filter(Category.name == category.name).first():
        raise HTTPException(status_code=400, detail="Category already exists.")

    # ✅ Create new category (unapproved)
    new_category = Category(
        name=category.name,
        description=category.description,
        is_approved=False,  # Admin must approve
        universal_user_id=current_user.id  # ✅ Link category to NGO
    )
    db.add(new_category)
    db.commit()
    db.refresh(new_category)

    return new_category


# 📥 Public: Get only approved categories
@router.get("/", response_model=list[CategoryResponse], summary="Public: Fetch only approved categories")
def get_approved_categories(db: Session = Depends(get_db)):
    return db.query(Category).filter(Category.is_approved == True).all()


# 🛡️ Admin: View all categories (approved & unapproved)
@router.get("/all", response_model=list[CategoryResponse], summary="Admin: Fetch all categories (Approved & Unapproved)")
def get_all_categories(
    db: Session = Depends(get_db),
    current_user: UniversalUser = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admins can access this resource.")

    return db.query(Category).all()


# ✅ Admin: Approve or reject a category
@router.patch("/{category_id}/approve", response_model=CategoryResponse, summary="Admin: Approve/Reject category")
def approve_category(
    category_id: int,
    approval: CategoryApproval,
    db: Session = Depends(get_db),
    current_user: UniversalUser = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admins can approve/reject categories.")

    category = db.query(Category).filter(Category.id == category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail="Category not found.")

    category.is_approved = approval.is_approved
    db.commit()
    db.refresh(category)

    return category
