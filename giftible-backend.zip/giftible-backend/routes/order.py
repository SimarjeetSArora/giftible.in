import os
import jwt
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import Order, OrderItem, Cart, CartItem, NGO, UniversalUser
from schemas import OrderResponse, UpdateOrderStatusRequest
from fastapi.security import OAuth2PasswordBearer
from services.razorpay_client import verify_payment_signature
from pydantic import BaseModel
from dotenv import load_dotenv
from jose import JWTError

router = APIRouter(prefix="/orders", tags=["Orders"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

load_dotenv()
SECRET_KEY = os.getenv("SECRET_KEY", "your_secret_key")
ALGORITHM = "HS256"

# 🔑 Utility: Get current user from token
def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> UniversalUser:
    try:
        if not token:
            raise HTTPException(status_code=401, detail="Token not provided.")

        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        contact_number = payload.get("sub")

        if not contact_number:
            raise HTTPException(status_code=401, detail="Invalid token payload.")

        user = db.query(UniversalUser).filter(UniversalUser.contact_number == contact_number).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found.")

        return user

    except JWTError as e:
        print(f"JWT Error: {e}")
        raise HTTPException(status_code=401, detail="Invalid or expired token.")

# 📦 Define the expected request body for placing an order
class PlaceOrderRequest(BaseModel):
    address_id: int
    coupon_code: str | None = None
    payment_id: str
    order_id: str
    amount: float
    signature: str

# ✅ Route to place an order after payment verification
@router.post("/place-order", summary="User: Place an order after payment verification")
def place_order(
    order_request: PlaceOrderRequest,
    db: Session = Depends(get_db),
    current_user: UniversalUser = Depends(get_current_user),
):
    try:
        print(f"📦 Incoming Order Request: {order_request.dict()}")

        # ✅ Verify payment signature
        is_verified = verify_payment_signature(
            order_request.order_id,
            order_request.payment_id,
            order_request.signature
        )

        if not is_verified:
            print("❌ Payment verification failed!")
            raise HTTPException(status_code=400, detail="❌ Payment verification failed.")

        print("✅ Payment verified successfully!")

        # ✅ Create order in the database
        order = Order(
            universal_user_id=current_user.id,
            address_id=order_request.address_id,
            total_amount=order_request.amount,
            razorpay_order_id=order_request.order_id,
            payment_id=order_request.payment_id,
            status="Pending"
        )
        db.add(order)
        db.commit()
        db.refresh(order)

        print(f"✅ Order placed with ID: {order.id}")

        return {"message": "✅ Order placed successfully!", "order_id": order.id}

    except HTTPException as http_err:
        raise http_err

    except Exception as e:
        db.rollback()
        print(f"❌ Error placing order: {e}")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

# 📦 Fetch user order history
@router.get("/user", response_model=list[OrderResponse], summary="User: Fetch order history")
def user_order_history(db: Session = Depends(get_db), current_user: UniversalUser = Depends(get_current_user)):
    orders = db.query(Order).filter(Order.universal_user_id == current_user.id).all()
    if not orders:
        raise HTTPException(status_code=404, detail="No orders found.")
    return orders

# 📋 NGO: View all received orders
@router.get("/ngo", response_model=list[OrderResponse], summary="NGO: View received orders")
def ngo_orders(db: Session = Depends(get_db), current_user: UniversalUser = Depends(get_current_user)):
    if current_user.role != "ngo":
        raise HTTPException(status_code=403, detail="Only NGOs can access this resource.")

    # ✅ Fetch orders where NGO's products are involved
    orders = db.query(Order).join(OrderItem).filter(OrderItem.ngo_id == current_user.id).all()
    
    if not orders:
        raise HTTPException(status_code=404, detail="No orders received.")
    
    return orders

# 🔄 NGO: Update Order Status
@router.put("/ngo/{order_id}/update-status", summary="NGO: Update order status")
def update_order_status(
    order_id: int,
    status_request: UpdateOrderStatusRequest,
    db: Session = Depends(get_db),
    current_user: UniversalUser = Depends(get_current_user)
):
    if current_user.role != "ngo":
        raise HTTPException(status_code=403, detail="Only NGOs can update order statuses.")

    # ✅ Fetch order item belonging to NGO
    order_item = db.query(OrderItem).filter(OrderItem.order_id == order_id, OrderItem.ngo_id == current_user.id).first()

    if not order_item:
        raise HTTPException(status_code=404, detail="Order item not found for your NGO.")

    order_item.status = status_request.status
    db.commit()
    return {"message": "✅ Order status updated successfully."}

# 📄 User: Get Order Details
@router.get("/{order_id}", response_model=OrderResponse, summary="User: Get detailed order information")
def get_order_details(order_id: int, db: Session = Depends(get_db), current_user: UniversalUser = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id, Order.universal_user_id == current_user.id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")
    return order
