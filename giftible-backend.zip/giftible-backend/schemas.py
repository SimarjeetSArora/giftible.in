from pydantic import BaseModel, EmailStr, constr, Field
from typing import Optional, List
from models import UsageLimit, OrderStatus
from datetime import datetime


# ✅ Common Schema for All Users
class UserBase(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    contact_number: str


# ✅ Schema for User Registration
class UserCreate(UserBase):
    password: str


# ✅ Schema for NGO Registration
class NGOCreate(BaseModel):
    ngo_name: str
    first_name: str
    last_name: str
    email: EmailStr
    contact_number: str
    password: str
    account_number: str  
    ifsc_code: str       


# ✅ Schema for Admin Registration
class AdminCreate(UserBase):
    password: str


# ✅ Response Schema for Users
class UserResponse(UserBase):
    id: int
    role: str

    class Config:
        from_attributes = True  # Updated for Pydantic v2


# ✅ CartItem Create Schema
class CartItemCreate(BaseModel):
    product_id: int
    quantity: int


# ✅ Address Create & Update Schemas
class AddressCreate(BaseModel):
    full_name: str = Field(..., max_length=100, description="Full name of the address holder")
    contact_number: str = Field(..., max_length=15, description="Contact number")
    address_line: str = Field(..., max_length=255, description="Street address")
    landmark: Optional[str] = Field(None, max_length=100, description="Nearby landmark (optional)")
    pincode: str = Field(..., max_length=10, description="Pincode of the address")
    city: str = Field(..., max_length=50, description="City name")
    state: str = Field(..., max_length=50, description="State name")
    is_default: bool


class AddressUpdate(BaseModel):
    full_name: Optional[str] = None
    contact_number: Optional[str] = None
    address_line: Optional[str] = None
    landmark: Optional[str] = None
    pincode: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None


# ✅ Coupon Schemas
class CouponApply(BaseModel):
    code: str


class CouponCreate(BaseModel):
    code: str
    discount_percentage: float
    max_discount: float  
    usage_limit: UsageLimit
    minimum_order_amount: float
    is_active: bool = True


class CouponResponse(BaseModel):
    id: int
    code: str
    discount_percentage: float
    usage_limit: str
    minimum_order_amount: float
    is_active: bool

    class Config:
        from_attributes = True  # Updated


# ✅ Order & Order Item Schemas
class OrderItemResponse(BaseModel):
    product_id: int
    quantity: int
    price: float

    class Config:
        from_attributes = True


class OrderResponse(BaseModel):
    id: int
    user_id: int
    ngo_id: int
    total_amount: float
    status: OrderStatus
    created_at: datetime
    updated_at: datetime
    order_items: List[OrderItemResponse]

    class Config:
        from_attributes = True


class UpdateOrderStatusRequest(BaseModel):
    status: OrderStatus


# ✅ Product Schemas
class ImageResponse(BaseModel):
    id: int
    image_url: str

    class Config:
        from_attributes = True


class ProductResponse(BaseModel):
    id: int
    name: str
    price: int
    description: Optional[str]
    images: List[ImageResponse] = []

    class Config:
        from_attributes = True


# ✅ NGO Response Schema (Fixed)
class NGOResponse(BaseModel):
    id: int
    ngo_name: str
    is_approved: bool
    logo: str
    first_name: str  # ✅ Fetch from UniversalUser
    last_name: str   # ✅ Fetch from UniversalUser
    email: str       # ✅ Fetch from UniversalUser
    contact_number: str  # ✅ Fetch from UniversalUser
    address: str  # ✅ Added missing field
    city: str     # ✅ Added missing field
    state: str    # ✅ Added missing field
    pincode: str  # ✅ Added missing field

    class Config:
        from_attributes = True


# ✅ Category Schemas
class CategoryCreate(BaseModel):
    name: str
    description: Optional[str] = None


class CategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    is_approved: bool

    class Config:
        from_attributes = True


class CategoryApproval(BaseModel):
    is_approved: bool


# ✅ Password Reset Schemas
class ForgotPasswordRequest(BaseModel):
    contact_number: constr(min_length=10, max_length=15)


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: constr(min_length=6)


# ✅ Search Result Schema
class SearchResult(BaseModel):
    id: int
    type: str
    name: str
    description: str


# ✅ Authentication Schemas
class RefreshTokenRequest(BaseModel):
    refresh_token: str


class LogoutRequest(BaseModel):
    refresh_token: str


# ✅ **User Profile Response (Fixed)**
class UserProfileResponse(BaseModel):
    id: int
    first_name: str  
    last_name: str  
    email: EmailStr
    contact_number: str
    role: str  

    class Config:
        from_attributes = True


# ✅ **Update Profile Schema (Fixed)**
class UserProfileUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    contact_number: Optional[str] = None
