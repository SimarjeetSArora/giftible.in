const API_BASE_URL = "http://localhost:8000"; // Change this when deploying

export default API_BASE_URL;
