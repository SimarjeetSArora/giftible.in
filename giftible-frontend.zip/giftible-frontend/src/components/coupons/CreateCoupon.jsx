import React, { useState } from "react";
import {
  Container,
  TextField,
  Button,
  Typography,
  Box,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Switch,
  FormControlLabel,
  Snackbar,
  Alert,
  useTheme,
} from "@mui/material";
import axiosInstance from "../../services/axiosInstance"; // ✅ Axios instance for API calls

function CreateCoupon() {
  const theme = useTheme();
  const isDarkMode = theme.palette.mode === "dark";

  const [couponData, setCouponData] = useState({
    code: "",
    discount_percentage: "",
    usage_limit: "one_time",
    minimum_order_amount: "",
    is_active: true,
  });

  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "info" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // ✅ Prevent negative values in numeric fields
    if ((name === "discount_percentage" || name === "minimum_order_amount") && value < 0) return;

    setCouponData((prev) => ({ ...prev, [name]: value }));
  };

  const handleToggle = () => {
    setCouponData((prev) => ({ ...prev, is_active: !prev.is_active }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!couponData.code || !couponData.discount_percentage || !couponData.minimum_order_amount) {
      return setSnackbar({ open: true, message: "⚠️ Please fill all required fields.", severity: "warning" });
    }

    try {
      await axiosInstance.post("/checkout/create-coupon", {
        code: couponData.code,
        discount_percentage: parseFloat(couponData.discount_percentage),
        usage_limit: couponData.usage_limit,
        minimum_order_amount: parseFloat(couponData.minimum_order_amount),
        is_active: couponData.is_active,
      });

      setSnackbar({ open: true, message: "✅ Coupon created successfully!", severity: "success" });

      // Reset Form
      setCouponData({ code: "", discount_percentage: "", usage_limit: "one_time", minimum_order_amount: "", is_active: true });

    } catch (error) {
      setSnackbar({ open: true, message: error.response?.data?.detail || "❌ Error creating coupon.", severity: "error" });
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom sx={{ color: isDarkMode ? "#F5B800" : "#6A4C93" }}>
        Create Coupon
      </Typography>

      <Box component="form" onSubmit={handleSubmit} mt={3}>
        <TextField
          label="Coupon Code"
          name="code"
          value={couponData.code}
          onChange={handleChange}
          fullWidth
          margin="normal"
          required
          sx={{ bgcolor: isDarkMode ? "#333" : "#fff" }}
        />

        <TextField
          label="Discount Percentage"
          name="discount_percentage"
          type="number"
          value={couponData.discount_percentage}
          onChange={handleChange}
          fullWidth
          margin="normal"
          required
          sx={{ bgcolor: isDarkMode ? "#333" : "#fff" }}
        />

        <FormControl fullWidth margin="normal">
          <InputLabel>Usage Limit</InputLabel>
          <Select
            name="usage_limit"
            value={couponData.usage_limit}
            onChange={handleChange}
            label="Usage Limit"
            sx={{ bgcolor: isDarkMode ? "#333" : "#fff" }}
          >
            <MenuItem value="one_time">One Time Use</MenuItem>
            <MenuItem value="one_per_day">One Per Day</MenuItem>
          </Select>
        </FormControl>

        <TextField
          label="Minimum Order Amount"
          name="minimum_order_amount"
          type="number"
          value={couponData.minimum_order_amount}
          onChange={handleChange}
          fullWidth
          margin="normal"
          required
          sx={{ bgcolor: isDarkMode ? "#333" : "#fff" }}
        />

        <FormControlLabel
          control={<Switch checked={couponData.is_active} onChange={handleToggle} />}
          label={couponData.is_active ? "Active" : "Inactive"}
          sx={{ mt: 2, color: isDarkMode ? "#F5B800" : "#1B1B1B" }}
        />

        <Button variant="contained" sx={{ bgcolor: "#6A4C93", color: "#FFFFFF", mt: 3 }} type="submit" fullWidth>
          Create Coupon
        </Button>
      </Box>

      {/* ✅ Snackbar Notifications */}
      <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={() => setSnackbar({ ...snackbar, open: false })}>
        <Alert severity={snackbar.severity} sx={{ width: "100%" }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
}

export default CreateCoupon;
